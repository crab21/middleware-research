A port of [Google's "Jump" Consistent Hash function](https://arxiv.org/abs/1406.2294)

Godoc: http://godoc.org/github.com/dgryski/go-jump
