package naming_client

import (
	"testing"
)

func TestHostReactor_GetServiceInfo(t *testing.T) {

}
