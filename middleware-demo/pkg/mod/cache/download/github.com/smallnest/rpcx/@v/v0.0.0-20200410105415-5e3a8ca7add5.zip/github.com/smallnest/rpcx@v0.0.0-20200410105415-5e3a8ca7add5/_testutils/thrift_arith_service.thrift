struct ThriftArgs
{
    1: i32 a,
    2: i32 b,
}


struct ThriftReply
{
    1: i32 c,
}