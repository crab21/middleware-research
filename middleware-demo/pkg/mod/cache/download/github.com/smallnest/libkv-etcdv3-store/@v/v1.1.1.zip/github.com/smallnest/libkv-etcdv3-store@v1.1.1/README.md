# libkv-etcdv3-store

[libkv](https://github.com/docker/libkv) only supports ETCD v2 API event if you use etcd 3.x.

This project implements a libkv store via etcd v3 API.

